﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AnthemBuilderLibrary;
using DBApp.Helpers;
using System.Net.Sockets;

namespace Tests
{
    [TestClass]
    public class LibraryTests
    {
        // Arrange
        // Act
        // Assert


        [TestMethod]
        public void SerializationTest()
        {
            // Arrange
            ServerMessage inputMessage = new ServerMessage();
            inputMessage.message = "!1message";
            inputMessage.comment = "!1comment";

            ServerMessage deserializedMessage = new ServerMessage();

            // Act
            SerializedServerMessage serializedInputMassage = ConnectionHelper.SerializeMessage(inputMessage);
            deserializedMessage = ConnectionHelper.DeserializeMessage(serializedInputMassage);

            // Assert

            Assert.AreEqual(inputMessage.comment, deserializedMessage.comment);
            Assert.AreEqual(inputMessage.message, deserializedMessage.message);
        }

        [TestMethod]
        public void AbstractClassTest()
        {
            // Arrange
            string title = "title";
            string content = "content";

            Tip generalTip = new GeneralTip();
            Tip classTip = new ClassTip();

            // Act
            generalTip.SetTip(title, content);
            classTip.SetTip(title, content);

            // Assert
            Assert.AreEqual(generalTip.ShowTip(), "► " + "GENERAL TIP | " + title + ": " + content + " Can be used on every class.");
            Assert.AreEqual(classTip.ShowTip(), "► " + "CLASS TIP | " + title + ": " + content + " Can only be used on this class.");
        }

        [TestMethod]
        public void SendMessageTest()
        {
            // Arrange
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ServerMessage message = new ServerMessage();
            message.message = "test";

            // Act
            socket.Close();

            // Assert
            Assert.ThrowsException<SocketException>(()=>ConnectionHelper.SendMessage(socket, message));
        }
    }
}
