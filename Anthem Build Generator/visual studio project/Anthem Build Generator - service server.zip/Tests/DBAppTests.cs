﻿using AnthemBuilderLibrary;
using Caliburn.Micro;
using DBApp;
using DBApp.Helpers;
using DBApp.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    [TestClass]
    public class DBAppTests
    {
        // Arrange
        // Act
        // Assert

        [TestMethod]
        public void SaltUniquenessTest()
        {
            // Arrange
            string generatedSalt1 = "same string";
            string generatedSalt2 = "same string";

            // Act
            generatedSalt1 = SaltHelper.GetRandomSalt();
            generatedSalt2 = SaltHelper.GetRandomSalt();

            // Assert
            Assert.AreNotEqual(generatedSalt1, generatedSalt2);
        }



        [TestMethod]
        public void PasswordHashingTest()
        {
            // Arrange
            string salt = "testsalt";
            string password1 = "testpassword";
            string password2 = "testpassword";
            string hashedPassword1 = "";
            string hashedPassword2 = "";
            string hashedPasswordWithSalt = "";

            // Act
            hashedPassword1 = HashingHelper.GetHashedPassword(password1);
            hashedPassword2 = HashingHelper.GetHashedPassword(password2);
            hashedPasswordWithSalt = HashingHelper.GetHashedPassword(password1 + salt);

            // Assert
            Assert.AreNotEqual(hashedPassword1, hashedPasswordWithSalt);
            Assert.AreEqual(hashedPassword1, hashedPassword2);


        }


        [TestMethod]
        public void IsValidEmailTest()
        {
            // Arrange
            string[] validEmails = { "a@b.c", "a.b@c.d", "a b@$.c" };
            string[] invalidEmails = { "", "@\"a", "@\"@a", "@\"a..b@c.d" };

            // Act
            // Assert
            foreach (string mail in validEmails)
            {
                Assert.IsTrue(RegisterViewModel.IsValidEmail(mail));
            }

            foreach (string mail in invalidEmails)
            {
                Assert.IsFalse(RegisterViewModel.IsValidEmail(mail));
            }
        }

    }
}
