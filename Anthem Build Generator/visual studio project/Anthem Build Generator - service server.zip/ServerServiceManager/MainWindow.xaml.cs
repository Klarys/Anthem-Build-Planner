﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ServerServiceManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceController sc;
        ServiceControllerStatus stat;
        public const string NazwaDziennika = "Dziennik mojej uslugi";
        public const string NazwaZrodla = "Server Service";

        public MainWindow()
        {
            InitializeComponent();


            sc = new ServiceController("ServerService");

            stat = sc.Status;

            if (sc.Status == ServiceControllerStatus.Running)
            {
                Stan.Text = "Włączono";
                OnButton.IsEnabled = false;

                NAdefault.IsEnabled = true;
                EUdefault.IsEnabled = true;
                NAoff.IsEnabled = true;
                NAon.IsEnabled = true;
                EUoff.IsEnabled = true;
                EUon.IsEnabled = true;
            }
            else if (sc.Status == ServiceControllerStatus.Stopped)
            {
                Stan.Text = "Wyłączono";
                OffButton.IsEnabled = false;

                NAdefault.IsEnabled = false;
                EUdefault.IsEnabled = false;
                NAoff.IsEnabled = false;
                NAon.IsEnabled = false;
                EUoff.IsEnabled = false;
                EUon.IsEnabled = false;
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e) //on
        {
            OnButton.IsEnabled = false;

            sc.Start();
            do
            {
                sc.Refresh();
            } while (sc.Status != ServiceControllerStatus.Running);


            //Thread.Sleep(1000);
            Stan.Text = sc.Status.ToString();

            if (OffButton.IsEnabled == false)
            {
                OffButton.IsEnabled = true;
            }
            NAdefault.IsEnabled = true;
            EUdefault.IsEnabled = true;
            NAoff.IsEnabled = true;
            NAon.IsEnabled = true;
            EUoff.IsEnabled = true;
            EUon.IsEnabled = true;

            RefreshLog();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //off
        {
            OffButton.IsEnabled = false;
            sc.Stop();
            do
            {
                sc.Refresh();
            } while (sc.Status != ServiceControllerStatus.Stopped);


            Stan.Text = sc.Status.ToString();

            if (OnButton.IsEnabled == false)
            {
                OnButton.IsEnabled = true;
            }

            NAdefault.IsEnabled = false;
            EUdefault.IsEnabled = false;
            NAoff.IsEnabled = false;
            NAon.IsEnabled = false;
            EUoff.IsEnabled = false;
            EUon.IsEnabled = false;

            RefreshLog();
        }

        private void RefreshLogButtonPress(object sender, RoutedEventArgs e)
        {
            RefreshLog();
        }

        public void RefreshLog()
        {
            EventLog eventLog = new EventLog(NazwaDziennika, ".", NazwaZrodla);

            EventLogEntryCollection myLogEntryCollection = eventLog.Entries;
            int myCount = myLogEntryCollection.Count;
            string _tmpLog = "";
            for (int i = 0; i < 10; i++)
            {
                if (myCount > i)
                {
                    EventLogEntry myLogEntry = myLogEntryCollection[myCount - i - 1];

                    _tmpLog += (i + 1).ToString() + ". " + myLogEntry.Source
                       + " was the source of an event: "
                       + myLogEntry.Message + " | (" + myLogEntry.TimeWritten + ")\n";
                }

            }
            LastEvents.Text = _tmpLog;
        }


        private void NASetDefault(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(255);
            RefreshLog();
        }

        private void EUSetDefault(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(254);
            RefreshLog();
        }

        private void NASetOff(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(253);
            RefreshLog();
        }

        private void EUSetOff(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(252);
            RefreshLog();
        }

        private void NASetOn(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(251);
            RefreshLog();
        }

        private void EUSetOn(object sender, RoutedEventArgs e)
        {
            sc.ExecuteCommand(250);
            RefreshLog();
        }
    }
}