﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnthemBuilderLibrary
{
    /// <summary>
    /// Class containing Id and a Name of an ingame class
    /// </summary>
    public class Class
    {
        public int ClassId { get; set; }

        public string Name { get; set; }

    }
}
