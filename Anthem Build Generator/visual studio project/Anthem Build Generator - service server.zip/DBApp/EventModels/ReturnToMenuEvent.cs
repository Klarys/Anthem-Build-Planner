﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBApp.EventModels
{
    /// <summary>
    /// Event used for switching to MainMenuView
    /// </summary>
    public class ReturnToMenuEvent
    {
    }
}
