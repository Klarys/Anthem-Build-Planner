﻿using AnthemBuilderLibrary;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServerService
{
    public partial class ServerService : ServiceBase
    {
        protected bool working = false;


        //pobranie domyślnych wartości z app.config
        private static NameValueCollection AllAppSettings = ConfigurationManager.AppSettings;
        public GameNews gameNews = new GameNews();
        public GameStatus gameStatus = new GameStatus();
        static bool DefaultNAstatus = Convert.ToBoolean(int.Parse(AllAppSettings["DefaultNAstatus"]));
        static bool DefaultEUstatus = Convert.ToBoolean(int.Parse(AllAppSettings["DefaultEUstatus"]));
        private bool CurrentNAstatus = Convert.ToBoolean(int.Parse(AllAppSettings["CurrentNAstatus"]));
        private bool CurrentEUstatus = Convert.ToBoolean(int.Parse(AllAppSettings["CurrentEUstatus"]));
        static string DefaultTitle = AllAppSettings["DefaultTitle"];
        static string DefaultLink = AllAppSettings["DefaultLink"];

        public const string NazwaDziennika = "Dziennik mojej uslugi";
        public const string NazwaZrodla = "Server Service";
        protected EventLog dziennik;

        private CancellationTokenSource _cancellationTokenSource;

        public ServerService()
        {
           // InitializeComponent();

            if (!EventLog.SourceExists(NazwaDziennika, "."))
            {
                EventLog.CreateEventSource(NazwaZrodla, NazwaDziennika);
            }
            dziennik = new EventLog(NazwaDziennika, ".", NazwaZrodla);
        }


        public async Task ProcessClientsRequest(CancellationToken token)
        {
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            int port = 55555;
            int queue = 15;

            try
            {
                IPAddress ip = IPAddress.Any;
                IPEndPoint endPoint = new IPEndPoint(ip, port);

                socket.Bind(endPoint);
                socket.Listen(queue);

                while (true)
                {
                    if(token.IsCancellationRequested)
                    {
                        dziennik.WriteEntry("Service cancellation token requested cancellation");
                        break;
                    }

                    Socket connectionSocket = socket.Accept();

                    await Task.Run(() =>
                        {
                            Console.WriteLine("New connection.");

                            ServerMessage receivedMessage = ConnectionHelper.ReceiveMessage(connectionSocket);
                            ServerMessage response = new ServerMessage();

                            if (receivedMessage.comment == "SERVERSTATUS")
                            {
                                response.comment = "SERVERSTATUS";
                                dziennik.WriteEntry("Client requested: serverstatus check.");
                                response.message = gameStatus;
                            }
                            else if (receivedMessage.comment == "GAMENEWS")
                            {
                                response.comment = "GAMENEWS";
                                dziennik.WriteEntry("Client requested: gamenews check.");
                                response.message = gameNews;
                            }
                            else
                            {
                                dziennik.WriteEntry("Incorrect request from the client.");
                            }

                            dziennik.WriteEntry("Sending a response for client's request...");
                            ConnectionHelper.SendMessage(connectionSocket, response);
                            dziennik.WriteEntry("Response sent.");
                        });
                }
            }
            catch (SocketException e)
            {
                dziennik.WriteEntry($"Socket exception!  {e}");
            }
            catch (Exception e)
            {
                dziennik.WriteEntry($"Other exception:  {e}");
            }
            finally
            {
                dziennik.WriteEntry("Server crashed.");
            }
        }


        protected override void OnStart(string[] args)
        {
            gameStatus.NAstatus = CurrentNAstatus;
            gameStatus.EUstatus = CurrentEUstatus;
            gameNews.title = DefaultTitle;
            gameNews.link = DefaultLink;
            dziennik.WriteEntry("Anthem server - start");

            _cancellationTokenSource = new CancellationTokenSource();
            Task.Run(() => ProcessClientsRequest(_cancellationTokenSource.Token));
        }

        protected override void OnStop()
        {

            _cancellationTokenSource.Cancel();
            _cancellationTokenSource.Dispose();
            dziennik.WriteEntry("Anthem server - stop");
        }

        public enum commands
        {
            commandNAdefault = 255, //set NAserver to default
            commandEUdefault = 254, //set EUserver to default
            commandNAoff = 253, //set NAserver to off
            commandEUoff = 252, //set EUserver to off
            commandNAon = 251, //set NAserver to on
            commandEUon = 250, //set EUserver to on
        }

        protected override void OnCustomCommand(int command)
        {

            base.OnCustomCommand(command);
            if (command == (int)commands.commandNAdefault)
            {
                string status = DefaultNAstatus ? "On" : "Off";

                if (gameStatus.NAstatus != DefaultNAstatus)
                {
                    gameStatus.NAstatus = DefaultNAstatus;
                    dziennik.WriteEntry($"NA server status changed to default ({status})");
                }
                else
                {
                    dziennik.WriteEntry($"NA server status was already equal to default ({status})");
                }
            }

            if (command == (int)commands.commandEUdefault)
            {
                string status = DefaultEUstatus ? "On" : "Off";

                if (gameStatus.EUstatus != DefaultEUstatus)
                {
                    gameStatus.EUstatus = DefaultEUstatus;
                    dziennik.WriteEntry($"EU server status changed to default ({status})");
                }
                else
                {
                    dziennik.WriteEntry($"EU server status was already equal to default ({status})");
                }
            }

            if (command == (int)commands.commandNAoff)
            {
                if (gameStatus.NAstatus != false)
                {
                    gameStatus.NAstatus = false;
                    dziennik.WriteEntry($"NA server status changed to Off");
                }
                else
                {
                    dziennik.WriteEntry($"NA server status was already set to Off");
                }
            }

            if (command == (int)commands.commandEUoff)
            {
                if (gameStatus.EUstatus != false)
                {
                    gameStatus.EUstatus = false;
                    dziennik.WriteEntry($"EU server status changed to Off");
                }
                else
                {
                    dziennik.WriteEntry($"EU server status was already set to Off");
                }
            }

            if (command == (int)commands.commandNAon)
            {
                if (gameStatus.NAstatus != true)
                {
                    gameStatus.NAstatus = true;
                    dziennik.WriteEntry($"NA server status changed to On");
                }
                else
                {
                    dziennik.WriteEntry($"NA server status was already set to On");
                }
            }

            if (command == (int)commands.commandEUon)
            {
                if (gameStatus.EUstatus != true)
                {
                    gameStatus.EUstatus = true;
                    dziennik.WriteEntry($"EU server status changed to On");
                }
                else
                {
                    dziennik.WriteEntry($"EU server status was already set to On");
                }
            }
        }
    }
}
